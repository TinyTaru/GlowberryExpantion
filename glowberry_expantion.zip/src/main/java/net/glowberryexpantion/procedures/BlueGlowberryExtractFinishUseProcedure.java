package net.glowberryexpantion.procedures;

public class BlueGlowberryExtractFinishUseProcedure {
	public static void execute() {
	}
}
