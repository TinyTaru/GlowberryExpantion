package net.glowberryexpantion.procedures;

public class LapisLaunchGemPropertyValueProviderProcedure {
	public static double execute() {
		return 0;
	}
}
